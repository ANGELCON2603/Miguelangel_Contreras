import 'package:flutter/material.dart';
import 'online_payment_screen.dart';
import 'product_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/payment', // Ruta inicial que lleva a OnlinePaymentScreen
      routes: {
        '/payment': (context) =>
            OnlinePaymentScreen(), // Ruta para la pantalla de pago
        '/': (context) => ProductScreen(), // Ruta para la pantalla de productos
      },
    );
  }
}
