import 'package:flutter/material.dart';
import 'product_screen.dart'; // Asegúrate de importar la pantalla de productos

class OnlinePaymentScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Fondo degradado que cubre toda la pantalla
          Container(
            height: MediaQuery.of(context)
                .size
                .height, // Asegura que ocupe toda la pantalla
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.blueAccent,
                  Colors.purpleAccent
                ], // Fondo degradado azul y morado
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          // Imagen en la parte superior
          Padding(
            padding: const EdgeInsets.only(top: 40.0),
            child: Align(
              alignment: Alignment.topCenter,
              child: Image.asset(
                'images/payment.png',
                width: 300, // Imagen más grande
              ),
            ),
          ),
          // Botón de retroceso en la parte superior izquierda
          Positioned(
            top: 40,
            left: 10,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () {
                Navigator.pop(context); // Regresar a la página anterior
              },
            ),
          ),
          // Botón de avance en la parte superior derecha
          Positioned(
            top: 40,
            right: 10,
            child: IconButton(
              icon: Icon(Icons.arrow_forward, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ProductScreen()), // Ir a ProductScreen
                );
              },
            ),
          ),
          // Encabezado y párrafo en la parte inferior
          Positioned(
            bottom:
                50, // Ajusta este valor según la distancia desde la parte inferior
            left: 20,
            right: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Only Payment',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),
                // Párrafo debajo del encabezado
                Text(
                  'Complete your transaction easily and securely.\nYour payment is being processed.\nThank you for using our service.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                    height: 1.5, // Controla el espacio entre las líneas
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
